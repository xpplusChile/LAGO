#define  _CRT_SECURE_NO_WARNINGS

#define _FILE_OFFSET_BITS  64

#ifndef EXP
#define EXP "LAGO"
#endif

/* Output format version */
#define DATAVERSION 		5
#define VERSION 				2
#define REVISION	 			0

#define MAXCHRLEN 			1024
#define BLOCKSIZE				16384
#define MAXFILENAMELEN	255
#define MAXPRESS 				1100 //1100Hpa
#define PRESSUREBLOCKSIZE	22
#define GPSBLOCKSIZE 			64

